gallerItem
>id,title,content,stub,staticFiles (js,images associated with each vizualization)

blogItem
>id,title,content
